$(window).scroll(function(){
    let wScroll = $(window).scrollTop();
    
    if(wScroll > $("nav").outerHeight())
    {
        $("nav").addClass("fixed-top") ;
         $("nav").css("backgroundColor","71B85F");
    }
    else{
    $("nav").css("backgroundColor","#71B85F");
    }
    
    $("nav a").click(function(){

     let aHref=$(this).attr("href");
    let  profileOffset =$(aHref).offset().top;
 
    $("body,html").animate({scrollTop:profileOffset},2000)

    })
})
function openNav() {
    document.getElementById("myNav").style.width = "100%";
  }
  
  
  function closeNav() {
    document.getElementById("myNav").style.width = "0%";
  }

















